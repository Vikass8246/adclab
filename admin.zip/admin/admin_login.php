<?php
// Connect to the database
$conn = new mysqli("localhost", "root", "", "user");
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

// Check if form has been submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
  // Get the username and password from the form
  $username = $_POST['username'];
  $password = $_POST['password'];

  // Validate the form fields
  if (!preg_match("/^[a-zA-Z0-9]+$/", $username)) {
    echo "Invalid username.";
  } elseif (strlen($password) < 8) {
    echo "Invalid password.";
  } else {
    // Get the hashed password for the username from the database
    $stmt = $conn->prepare("SELECT password FROM administrators WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($result->num_rows > 0) {
      $row = $result->fetch_assoc();
      $hashed_password = $row['password'];

      // Verify the password
      if (password_verify($password, $hashed_password)) {
        // Store the username in the session
        session_start();
        $_SESSION['username'] = $username;

        // Redirect to the admin panel page
        header("Location: admin_panel.php");
        exit;
      } else {
        echo "Invalid password.";
      }
    } else {
      echo "Username not found.";
    }

    // Close the prepared statement
    $stmt->close();
  }
}

// Close the database connection
$conn->close();
?>

<!-- Login form -->
<form method="post">
  <input type="text" name="username" placeholder="Username">
  <input type="password" name="password" placeholder="Password">
  <input type="submit" value="Login">
</form>
