<?php
require('database_connection.php');

session_start();

if (!isset($_SESSION['admin']) || $_SESSION['admin'] !== true) {
    header("location: login.php"); // Redirect to login page if not logged in as admin
    exit();
}

$username = $_SESSION['username']; // Retrieve admin username from session

// Check if the form to add a new user is submitted
if (isset($_POST['add_user'])) {
    // Retrieve user details from the form
    $name = mysqli_real_escape_string($con, $_POST['full_name']);
    $username = mysqli_real_escape_string($con, $_POST['username']);
    $email = mysqli_real_escape_string($con, $_POST['email']);
    $password = password_hash($_POST['password'], PASSWORD_BCRYPT); // Hash the password

    // Insert the new user into the database
    $insertQuery = "INSERT INTO register (full_name, username, email, password) VALUES ('$name', '$username', '$email', '$password')";

    try {
        if (mysqli_query($con, $insertQuery)) {
            echo 'User added successfully.';
        } else {
            throw new Exception(mysqli_error($con));
        }
    } catch (Exception $e) {
        // Check if the error is due to a duplicate entry (username or email)
        if (mysqli_errno($con) == 1062) {
            // Set a session variable with the alert message
            $_SESSION['duplicate_alert'] = "User with username $username and $email is already registered.";
        } else {
            echo "<script>alert('Error adding user: " . $e->getMessage() . "')</script>";
        }
    }
}

// Display user details and delete links
$query = "SELECT * FROM register";
$result = mysqli_query($con, $query);

if (!$result) {
    echo 'Error retrieving user details: ' . mysqli_error($con);
    exit();
}

$users = mysqli_fetch_all($result, MYSQLI_ASSOC);

// Check if a duplicate alert is set in the session
if (isset($_SESSION['duplicate_alert'])) {
    echo "<script>alert('{$_SESSION['duplicate_alert']}')</script>";
    unset($_SESSION['duplicate_alert']); // Clear the session variable
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel</title>
    <meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate">
    <meta http-equiv="Pragma" content="no-cache">
    <meta http-equiv="Expires" content="0">
    <script>
    if (window.history.replaceState) {
        window.history.replaceState(null, null, window.location.href);
    }
</script>

</head>

<body>

    <h1>Welcome to Admin Panel,
        <?php echo $username; ?>
    </h1>

    <!-- Form to add a new user -->
    <form method="post" action="">
        <label for="full_name">Name:</label>
        <input type="text" name="full_name" required>
        <br>
        <label for="username">User Name:</label>
        <input type="text" name="username" required>
        <br>
        <label for="email">Email:</label>
        <input type="email" name="email" required>
        <br>
        <label for="password">Password:</label>
        <input type="password" name="password" required>
        <br>
        <button type="submit" name="add_user">Add User</button>
    </form>

    <table border="1">
        <thead>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Email</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($users as $user): ?>
                <tr>
                    <td>
                        <?php echo $user['id']; ?>
                    </td>
                    <td>
                        <?php echo $user['username']; ?>
                    </td>
                    <td>
                        <?php echo $user['email']; ?>
                    </td>
                    <td>
                        <a href="edit_user.php?id=<?php echo $user['id']; ?>">Edit</a>
                        |
                        <a href="delete_user.php?id=<?php echo $user['id']; ?>">Delete</a>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>

</body>

</html>