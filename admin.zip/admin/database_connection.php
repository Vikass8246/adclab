<?php

$con=mysqli_connect("localhost","root","","registration");

if(mysqli_connect_error())
{
    echo"<script>alert('Cannot connect to the databse');</script>";
    exit();
}

?>
