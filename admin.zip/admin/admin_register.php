<?php
// Connect to the database
$conn = new mysqli("localhost", "root", "", "user");
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

// Check if form has been submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
  // Get the username and password from the form
  $username = $_POST['username'];
  $password = $_POST['password'];

  // Validate the form fields
  if (!preg_match("/^[a-zA-Z0-9]+$/", $username)) {
    echo "Username must only contain letters and numbers.";
  } elseif (strlen($username) < 5) {
    echo "Username must be at least 5 characters long.";
  } 
  elseif (strlen($password) < 8) {
    echo "Password must be at least 8 characters long.";
  } else {
    // Check if the username is already taken
    $stmt = $conn->prepare("SELECT id FROM administrators WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($result->num_rows > 0) {
      echo "Username already exists.";
    }
    else {
      // Hash the password
      $hashed_password = password_hash($password, PASSWORD_DEFAULT);

      // Insert the new admin into the database
      $stmt = $conn->prepare("INSERT INTO administrators (username, password) VALUES (?, ?)");
      $stmt->bind_param("ss", $username, $hashed_password);
      $stmt->execute();

      echo "Admin registered successfully.";
    }

    // Close the prepared statement
    $stmt->close();
  }
}

// Close the database connection
$conn->close();
?>

<!-- Registration form -->
<form method="post">
  <input type="text" name="username" placeholder="Username">
  <input type="password" name="password" placeholder="Password">
  <input type="submit" value="Register">
  <input type="button" value="Click Here to Login" onClick="myOnClick()">
</form>


<script>
        function myOnClick(){
          document.location.href="admin_login.php";
        }
      </script>
</html>