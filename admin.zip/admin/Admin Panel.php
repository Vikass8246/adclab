<!DOCTYPE html>
<html lang="en>
<head>
    <meta charset="UTF-8">
    <title>ADC Admin</title>
    <link rel="stylesheet" href="https://maxst.icons8.com/vue-static/landings/line-awesome/font-awesome-line-awesome/css/all.min.css">
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="sidebar">
        <div class="side-brand">
           <h1><span class="las la-accusoft"></span>ADC</h1> 
        </div>
    </div>

</body>
</html>


