<?php
$servername = "localhost";
$username = "database_username";
$password = "database_password";
$dbname = "database_name";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

// Check if form has been submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
  $username = mysqli_real_escape_string($conn, $_POST['username']);
  $email = mysqli_real_escape_string($conn, $_POST['email']);
  $password = mysqli_real_escape_string($conn, $_POST['password']);

  // Hash the password for security
  $password = password_hash($password, PASSWORD_DEFAULT);

  // Insert the details into the database
  $sql = "INSERT INTO administrators (username, email, password)
  VALUES ('$username', '$email', '$password')";

  if ($conn->query($sql) === TRUE) {
    echo "Admin registered successfully.";
  } else {
    echo "Error: " . $sql . "<br>" . $conn->error;
  }
}

$conn->close();
?>

<!-- The HTML form for registering an admin -->
<form action="admin_register.php" method="post">
  <div>
    <label for="username">Username:</label>
    <input type="text" name="username" id="username">
  </div>
  <div>
    <label for="email">Email:</label>
    <input type="email" name="email" id="email">
  </div>
  <div>
    <label for="password">Password:</label>
    <input type="password" name="password" id="password">
  </div>
  <div>
    <input type="submit" value="Sign Up">
  </div>
</form>
