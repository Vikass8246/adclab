<?php
// Get form data
$name = $_POST['name'];
$email = $_POST['email'];
$phone = $_POST['phone'];
$selectedTests = isset($_POST['tests']) ? $_POST['tests'] : [];
$appointment_date = $_POST['appointment_date'];
$appointment_time = $_POST['appointment_time'];

$con = mysqli_connect('localhost', 'root', '', 'registration');

// Insert appointment data into the database
$query = "INSERT INTO booking_appoinment (name, email, phone, appointment_date, appointment_time) VALUES ('$name', '$email', '$phone', '$appointment_date', '$appointment_time')";
mysqli_query($con, $query);
$appointmentId = mysqli_insert_id($con); // Get the last inserted appointment ID

// Set the appointment ID in the session
$_SESSION['appointment_id'] = $appointmentId;

// Insert selected tests into a separate table
foreach ($selectedTests as $test) {
  // Retrieve the price for the test
  $priceQuery = "SELECT price FROM tests WHERE test_name = '$test'";
  $priceResult = mysqli_query($con, $priceQuery);

  if ($priceResult) {
      $priceRow = mysqli_fetch_assoc($priceResult);
      $price = $priceRow['price'];

      // Replace 'price' with the actual column name where the test price is stored
      $testQuery = "INSERT INTO selected_tests (appointment_id, test_name, price) VALUES ('$appointmentId', '$test', '$price')";
      mysqli_query($con, $testQuery);
  } else {
      echo 'Error retrieving price: ' . mysqli_error($con);
  }
}





// Calculate total price based on selected tests
$totalPriceQuery = "SELECT SUM(price) AS total_price FROM selected_tests WHERE appointment_id = '$appointmentId'";
$totalPriceResult = mysqli_query($con, $totalPriceQuery);
$totalPriceRow = mysqli_fetch_assoc($totalPriceResult);
$totalPrice = $totalPriceRow['total_price'];


if (sendMail($email, $name, $appointment_date, $appointment_time, $selectedTests, $totalPrice)) {
  // Redirect to a confirmation page
  header('Location: confirmation.html');
} else {
  echo 'Error sending email';
}

// Send email notification
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

function sendMail($email, $name, $appointment_date, $appointment_time, $selectedTests, $totalPrice)
{
    require './PHPMailer-master/src/PHPMailer.php';
    require './PHPMailer-master/src/SMTP.php';
    require './PHPMailer-master/src/Exception.php';

    $mail = new PHPMailer(true);

    try {
        // SMTP Configuration
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'vikasyadav826853073@gmail.com';
        $mail->Password = 'jwsd nuia txkt omlu';
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port = 587;

        $mail->setFrom('vikasyadav826853073@gmail.com', 'Ashwani Diagnostic Center');
        $mail->addAddress($email);
        $mail->Subject = 'Appointment Booking Confirmation';
        $message = "Dear $name,\n\nYour appointment has been booked on $appointment_date at $appointment_time.\n\nSelected Tests:\n";
        foreach ($selectedTests as $test) {
            $message .= "- $test\n";
        }
        $message .= "\nTotal Price: $totalPrice\n\nThank you for choosing our service.";

        $mail->Body = $message;

        // Send the email
        $mail->send();

        return true;
    } catch (Exception $e) {
        return false;
    }
}

// // Send email notification
// if (sendMail($email, $name, $appointment_date, $appointment_time, $selectedTests, $totalPrice)) {
//   // Redirect to a confirmation page
//   header('Location: confirmation.html');
// } else {
//   echo 'Error sending email';
// }
?>
