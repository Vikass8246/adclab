<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Appointment Booking Form</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.13/css/select2.min.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.13/js/select2.min.js"></script>
    <style>
        /* Style for the searchable dropdown */
        .select2-container--default .select2-selection--multiple {
            border-radius: 5px;
            border: 1px solid #ccc;
        }
    </style>
    <script>
        // JavaScript function to calculate the total price
        function calculateTotal() {
            var testsSelect = document.getElementById('tests');
            var totalPriceDisplay = document.getElementById('totalPrice');

            var selectedTests = testsSelect.selectedOptions;
            var total = 0;

            for (var i = 0; i < selectedTests.length; i++) {
                var testPrice = parseFloat(selectedTests[i].getAttribute('data-price')) || 0;
                total += testPrice;
            }

            totalPriceDisplay.textContent = '$' + total.toFixed(2);
        }
    </script>
</head>

<body>

    <!-- Your form content here -->

    <form method="post" action="appoinment1.php" onsubmit="calculateTotal()">
        <label for="name">Name:</label>
        <input type="text" name="name" required><br>

        <label for="email">Email:</label>
        <input type="email" name="email" required><br>

        <label for="phone">Phone:</label>
        <input type="tel" name="phone" required><br>

        <label for="test">Select Test(s):</label>
        <select id="tests" name="tests[]" class="js-example-basic-multiple" multiple="multiple"
            onchange="calculateTotal()" required>
            <option value="" disabled>Select Tests</option>
            <option value="CBC" data-price="250">CBC</option>
            <option value="ESR" data-price="150">ESR</option>
            <option value="FASTING SUGAR" data-price="50">FASTING SUGAR</option>
            <option value="POST LUNCH SUGAR" data-price="50">POST LUNCH SUGAR</option>
            <option value="RT-PCR" data-price="500">RT-PCR</option>
            <option value="RANDOM SUGAR" data-price="100">RANDOM SUGAR</option>
            <option value="BLOOD GROUP" data-price="70">BLOOD GROUP</option>
            <option value="URINE CULTURE" data-price="60">URINE CULTURE</option>
            <option value="DENGUE NS1" data-price="50">DENGUE NS1</option>
            <option value="HBA1C" data-price="150">HBA1C</option>
            <!-- Add more test options as needed -->
        </select><br>

        <label>Total Price:</label>
        <span id="totalPrice">$0.00</span><br>

        <label for="appointment_date">Appointment Date:</label>
        <input type="date" name="appointment_date" required><br>

        <label for="appointment_time">Appointment Time:</label>
        <input type="time" name="appointment_time" required><br>

        <button type="submit">Book Appointment</button>
    </form>



    <script>
        // Activate Select2 on your multi-select dropdown
        $(document).ready(function () {
            $(".js-example-basic-multiple").select2({
                width: "10%"
            });
        });
    </script>

</body>

</html>